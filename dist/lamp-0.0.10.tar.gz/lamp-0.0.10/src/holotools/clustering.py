#!/usr/bin/env python3
'''Binders and Tools for Clustering of Bacterial Sequences'''
def test():
    print('This is a test of pypi and pip')
