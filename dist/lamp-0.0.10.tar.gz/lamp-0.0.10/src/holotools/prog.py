#!/usr/bin/env python3
from time import sleep
import sys

for i in range(21):
    sys.stdout.write('\r')
    # the exact output you're looking for:
    sys.stdout.write("[%-20s] %d%%" % ('$'*i, 5*i))
    sys.stdout.flush()
    sleep(0.25)
