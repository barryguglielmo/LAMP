#!/usr/bin/env python3
'''Just Make Biopython DataMine Work With Less Key Strokes'''
def pubmed(lst, api_key, email, retmax = 50):
    from Bio import Entrez
    import os
    try:
        os.mkdir('ncbi')
    except:
        print('overwrite ncbi folder')
    cwd = os.getcwd()
    Entrez.api_key = api_key
    Entrez.email = email
    for i in lst:
        print (i)
        search_results = Entrez.read(Entrez.esearch(db="pubmed", term=i+"[ORGN]", reldate=365, datetype="pdat", usehistory="y"))
        count = int(search_results["Count"])
        if count>retmax:
            count = retmax
        batch_size = 1
        os.mkdir(cwd+'/ncbi/'+i.replace(' ','_'))
        for start in range(0, count, batch_size):
            out_handle = open(cwd+"/ncbi/%s/%s_%i.txt"%(i.replace(' ','_'),i.replace(' ','_'),start), "w")
            end = min(count, start + batch_size)
            if start %10==0:
                print(start)
            fetch_handle = Entrez.efetch(
                db="pubmed",
                rettype="gb",
                retmode="text",
                retstart=start,
                retmax=batch_size,
                webenv=search_results["WebEnv"],
                query_key=search_results["QueryKey"],
            )
            data = fetch_handle.read()
            fetch_handle.close()
            out_handle.write(data)
        out_handle.close()
