#!/usr/bin/env python3
'''NLTK Tools'''
def token_tag(abstract,stemlem = 'lem', add_drop = 'add_drop.tsv',column = 'word'):
    import pandas as pd
    import nltk
    import os
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    from nltk.stem.lancaster import LancasterStemmer
    if stemlem == 'stem':
        stemlem = LancasterStemmer().stem
    elif stemlem == 'lem':
        stemlem = WordNetLemmatizer().lemmatize
    tokenizer = nltk.RegexpTokenizer(r"\w+")
    tokens = tokenizer.tokenize(abstract)
    token = [i for i in tokens if i.isdigit()==False]
    mystop = list(pd.read_csv(add_drop,sep='\t')[column].values)
    stop_words = stopwords.words('english')+mystop
    token = [i.lower() for i in token if i not in stop_words]
    #drop two letter words
    token = [i for i in token if len(i)>2]
    token = [stemlem(i) for i in token]
    return token
def word_stats(file_list, mymin =5):
    counts = {}
    for file in file_list:
        h = ''.join(open(file,'r').readlines())
        token, tag = token_tag(h)
        for i in token:
            if i in counts.keys():
                counts[i]+=1
            else:
                counts[i]=1
    if mymin<0:
        counts = {key:val for key, val in counts.items() if val <abs(mymin)}
    else:
        counts = {key:val for key, val in counts.items() if val > mymin}

    return counts
def word_cloud(word_stats='word_stats.tsv',cmap = 'gray', font_path = '/home/boom/anaconda3/lib/fonts/DejaVuMathTeXGyre.ttf'):
    from wordcloud import WordCloud, STOPWORDS
    import matplotlib.pyplot as plt
    import pandas as pd
    import matplotlib.pyplot as plt

    df = pd.read_csv(word_stats, sep='\t')
    words = []
    for i in range(0,len(df)):
        for j in range(0,df['count'][i]):
            words.append(df['word'][i])
    words = [i for i in words if type(i) is not float]
    wordcloud = WordCloud(width = 800, height = 800,
                    colormap=cmap,
                    background_color ='white',
                    font_path=font_path,
                    min_font_size = 10,collocations=False).generate(' '.join(words))
    # plot the WordCloud image
    plt.figure(figsize = (8, 8), facecolor = None)
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.tight_layout(pad = 0)

    plt.show()
